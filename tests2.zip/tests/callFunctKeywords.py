def foo(bar):
    print bar

foo( "hello", bar="hi" )

foo( bar="hi" )
