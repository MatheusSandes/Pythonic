from collections import Counter

ct = Counter('abracadabra')
print(ct)