squaredNumbers = [x*x for x in xrange(100)]
for number in squaredNumbers:
    print(number)
