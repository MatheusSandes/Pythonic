class magicMethods():
    def __init__():
        pass
    def __str__():
        pass
