with open('output.txt', 'w') as fd:
    fd.write('Hi world!')
