colors = ['a', 'b', 'c']

for i in range(len(colors)):
    print color[i]
